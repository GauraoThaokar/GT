import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'upgrade-cmp',
    moduleId: module.id,
    templateUrl: 'upgrade.component.html'
})

export class UpgradeComponent implements OnInit{
    ngOnInit(){
    }
}
