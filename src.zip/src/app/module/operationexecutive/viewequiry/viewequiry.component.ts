import { Component, OnInit } from '@angular/core';
import { Enquirydetails } from 'app/model/enquirydetails';
import { EnquiryServiceServiceService } from 'app/module/shared/enquiry-service-service.service';

@Component({
  selector: 'app-viewequiry',
  templateUrl: './viewequiry.component.html',
  styleUrls: ['./viewequiry.component.css']
})
export class ViewequiryComponent implements OnInit {

  enquirydetailslist:Enquirydetails[]
  constructor(public es:EnquiryServiceServiceService) { }

  ngOnInit(): void {
    this.es.getAll().subscribe((data:Enquirydetails[])=>
    {
      
      this.enquirydetailslist=data;
      console.log("Data :"+this.enquirydetailslist[0].cibil.cibilScore);
    })
  }

  getCibil(eId)
{
 // if(this.es.eID==0)
 // {
  console.log("eid" + eId);
    this.es.getCibil(eId).subscribe();
    this.ngOnInit();
 // }
 // else{
   // this.es.update().subscribe()
  //}
 
}

}
