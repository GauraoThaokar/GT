import { TestBed } from '@angular/core/testing';

import { EnquiryServiceServiceService } from './enquiry-service-service.service';

describe('EnquiryServiceServiceService', () => {
  let service: EnquiryServiceServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EnquiryServiceServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
