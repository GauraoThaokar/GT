import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AllPersonalDoc } from 'app/model/all-personal-doc';
import { Customer } from 'app/model/Customer';
import { Enquirydetails } from 'app/model/enquirydetails';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EnquiryServiceServiceService {

  eId:number;
  firstName:String;
  lastName:String;
  age:number;
  email:string;
  mobileno:number;
  pancardNo:string;
  cibilscore:number

  
  constructor(private http: HttpClient) { }
  ed:Enquirydetails={
    eId:0,
    firstName:'',
    lastName:'',
    age:0,
    email:'',
    mobileno:0,
    pancardNo:'',
    cibil:null
  }
  custobj:Customer={
    cId : 0,
    cname : '',
    accountdetails : 
    {
      accountid : 0,
      accounttype : '',
      accountbalance : 0,
      accountholdername : '',
      accountstatus : '',
      accountnumber : 0

    },
    currentloandetails :
    {
      loanId : 0,
      loanAmount : 0,
      loanRoi : 0,
      loanTenure : 0,
      loanAmounttobePaid : 0,
      sanctionAmount : 0,
      emidetails : {

        emiId : 0,
        emiAmountMonthly : 0,
        nextEmiDueDate : '',
        previousEmiStatus : '',

      },
      previousloandetails : {

        preloanId : 0,
        preloanAmount : 0,
        preloanTenure : 0,
        preloanEmi : 0,
        preloanPaidAmount : 0,
        preloanRemainingAmount : 0,
        preLoanType : '',
        preLoanStauts : '',

        
      }
    }
   
  }

  cs:AllPersonalDoc={
    documentID: 0,
    cId: 0,
    adharcard: [],
    pancard: [],
    addressproof: []
  }


  url:string="http://localhost:9091"
  save()
  {
   return this.http.post<Enquirydetails>(this.url+"/saveenq",this.ed)
  }
  getCibil(eId)
  {
   // console.log("eid" + this.ed.eId);
   return this.http.get<String>(this.url+"/getcibil/"+eId);
  }
  savecust()
  {
   //return this.http.post<Customer>(this.url+"/savecustomerdata",this.custobj)
   return this.http.post<Customer>(this.url+"/singlecustomer",this.custobj);
  }
  update()
  {
    return null  // this.http.put<Enquirydetails>(this.url+"/update",this.ed)
  }
  delete(id:number)
  {
    return null // this.http.delete<Enquirydetails>(this.url+"/delete/"+id)
  }
  getAll():any
  {
    return this.http.get<Enquirydetails>(this.url+"/getenqlist")
  }

  uploaddoc(em:FormData){

    alert("in cs")
  console.log(em);

  return this.http.post(this.url+"/docupload", em);

  }
 

getDoc(id:number):Observable<any>{
  alert("in service")
    return this.http.get<Document[]>(this.url+"/getSingleData/"+id);
  
  }

  
}


