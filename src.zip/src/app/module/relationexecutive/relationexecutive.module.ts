import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerregisterComponent } from './customerregister/customerregister.component';
import { DocumentComponent } from './document/document.component';
import { EnquiryComponent } from './enquiry/enquiry.component';
import { RouterModule, Routes } from '@angular/router';
import { EnquiryviewComponent } from './enquiry/enquiryview/enquiryview.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';


const routing: Routes = [
  {path: 'oeenquiry', component:EnquiryComponent },
  {path:'oecustomer',component:CustomerregisterComponent},
  {path:'oedocument',component:DocumentComponent},
  {path:'oeenq',component:EnquiryviewComponent}

  
];
@NgModule({
  declarations: [CustomerregisterComponent, DocumentComponent, EnquiryComponent, EnquiryviewComponent],
  imports: [
    FormsModule,CommonModule,RouterModule.forChild(routing),ReactiveFormsModule
  ]
})
export class RelationexecutiveModule { }
