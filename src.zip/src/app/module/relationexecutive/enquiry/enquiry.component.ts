import { Component, OnInit } from '@angular/core';
import { Enquirydetails } from 'app/model/enquirydetails';
import { EnquiryServiceServiceService } from 'app/module/shared/enquiry-service-service.service';

@Component({
  selector: 'app-enquiry',
  templateUrl: './enquiry.component.html',
  styleUrls: ['./enquiry.component.css']
})
export class EnquiryComponent implements OnInit {

  enquirydetailslist:Enquirydetails[]

  constructor(public es:EnquiryServiceServiceService) { }
  ngOnInit(): void {
    
      }
  save()
{
 // if(this.es.eID==0)
 // {
    this.es.save().subscribe()
 // }
 // else{
   // this.es.update().subscribe()
  //}
 
}
}
