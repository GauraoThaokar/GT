import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EnquiryviewComponent } from './enquiryview.component';

describe('EnquiryviewComponent', () => {
  let component: EnquiryviewComponent;
  let fixture: ComponentFixture<EnquiryviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EnquiryviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EnquiryviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
