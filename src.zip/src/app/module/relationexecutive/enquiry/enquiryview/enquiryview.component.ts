import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Enquirydetails } from 'app/model/enquirydetails';
import { EnquiryServiceServiceService } from 'app/module/shared/enquiry-service-service.service';

@Component({
  selector: 'app-enquiryview',
  templateUrl: './enquiryview.component.html',
  styleUrls: ['./enquiryview.component.css']
})
export class EnquiryviewComponent implements OnInit {

  enquirydetailslist:Enquirydetails[]
  constructor(public es:EnquiryServiceServiceService,private router: Router) { }


  ngOnInit(): void {
    this.es.getAll().subscribe((data:Enquirydetails[])=>
    {
      
      this.enquirydetailslist=data;
      console.log("Data :"+this.enquirydetailslist[0].cibil.cibilScore);
    })
   }
   registerCustomer(){
    this.router.navigateByUrl("role/relation/oecustomer");

   }
  // update(a:Enquirydetails){
  //  // this.es.ed=a
  // }
  // delete(id:number){
  //  // this.es.delete(id).subscribe()
  // }
  

}
