import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EnquiryServiceServiceService } from 'app/module/shared/enquiry-service-service.service';

@Component({
  selector: 'app-customerregister',
  templateUrl: './customerregister.component.html',
  styleUrls: ['./customerregister.component.css']
})
export class CustomerregisterComponent implements OnInit {

  

  constructor(public es:EnquiryServiceServiceService,public router:Router ) { }
  step:number;
  
  ngOnInit(): void {
    this.step = 1;
  }

  next() {
    this.step = this.step + 1;
  }
  
  previous() {
    this.step = this.step - 1;
  }
     
  save()
   {
        alert("data saved");
    this.es.savecust().subscribe();
 
       //this.cs.saveInfo(this.CregForm.value).subscribe((no:number)=>{
      //this.es.custobj.cId=no;
       console.log(this.es.custobj.cId);
      
    
  
    this.router.navigateByUrl("role/relation/oedocument");
   }
 
  }
  

