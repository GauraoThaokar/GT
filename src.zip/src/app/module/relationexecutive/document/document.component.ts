import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EnquiryServiceServiceService } from 'app/module/shared/enquiry-service-service.service';
@Component({
  selector: 'app-document',
  templateUrl: './document.component.html',
  styleUrls: ['./document.component.css']
})
export class DocumentComponent implements OnInit {

  constructor(public fb:FormBuilder,public es:EnquiryServiceServiceService,private router: Router) { }

   retriveddoc:any;

   adharcard:any;
	 pancard:any;
	 addressproof:any;
   docform:FormGroup;
  
   ngOnInit(): void {

    this.docform=this.fb.group({

      cId:[this.es.custobj.cId,[Validators.required]],
    })

     
    
  }

  onFileSelected() {
    const inputNode: any = document.querySelector('#file');
  
    if (typeof (FileReader) !== 'undefined') {
      const reader = new FileReader();
  
      reader.onload = (e: any) => {
        this.retriveddoc = e.target.result;
      };
  
      reader.readAsArrayBuffer(inputNode.files[0]);
    }
}
onselectFile1(event:any){

  this.adharcard=event.target.files[0];
} 
onselectFile2(event:any){

  this.pancard=event.target.files[0];
}

onselectFile3(event:any){

  this.addressproof=event.target.files[0];
}

// onselectFile3(event:any){

//   this.pancard=event.target.files[0];
// }

// onselectFile4(event:any){

//   this.incomeproof=event.target.files[0];
// }

submit(){  
 
  alert("In document")
  const d=JSON.stringify(this.docform.value);

  const em=new FormData();
  em.append("adharcard",this.adharcard);
  em.append("pancard",this.pancard);
  em.append("addressproof",this.addressproof);
  
  em.append("cId",d);
 
  console.log(em)

 this.es.uploaddoc(em).subscribe();

 this.es.custobj.cId=0;
 this.ngOnInit();
}
}
