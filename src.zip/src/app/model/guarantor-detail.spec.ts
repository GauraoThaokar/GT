import { GuarantorDetail } from './guarantor-detail';

describe('GuarantorDetail', () => {
  it('should create an instance', () => {
    expect(new GuarantorDetail()).toBeTruthy();
  });
});
