import { CustomerVerification } from './customer-verification';

describe('CustomerVerification', () => {
  it('should create an instance', () => {
    expect(new CustomerVerification()).toBeTruthy();
  });
});
