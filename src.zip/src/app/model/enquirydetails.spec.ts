import { Enquirydetails } from './enquirydetails';

describe('Enquirydetails', () => {
  it('should create an instance', () => {
    expect(new Enquirydetails()).toBeTruthy();
  });
});
