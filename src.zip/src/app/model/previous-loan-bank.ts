export class PreviousLoanBank {
    branchId:number;
    branchName:string;
    branchCode:number;
    branchType:string;
    ifscCode:string;
    micrCode:string;
    contactNumber:number;
    bankAddress:string;
    email:string;
    status:string;





}
