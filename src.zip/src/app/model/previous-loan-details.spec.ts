import { PreviousLoanDetails } from './previous-loan-details';

describe('PreviousLoanDetails', () => {
  it('should create an instance', () => {
    expect(new PreviousLoanDetails()).toBeTruthy();
  });
});
