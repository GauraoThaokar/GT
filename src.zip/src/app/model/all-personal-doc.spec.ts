import { AllPersonalDoc } from './all-personal-doc';

describe('AllPersonalDoc', () => {
  it('should create an instance', () => {
    expect(new AllPersonalDoc()).toBeTruthy();
  });
});
