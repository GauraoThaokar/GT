export class EmiDetail {
    emiId:number;
    emiAmountMonthly:number;
    nextEmiDueDate:string;
    previousEmiStatus:string;
}
