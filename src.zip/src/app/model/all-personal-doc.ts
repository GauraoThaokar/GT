export class AllPersonalDoc {

     documentID:number;
     cId:number;
     adharcard:[];
	 pancard:[];
	 addressproof:[];
}
