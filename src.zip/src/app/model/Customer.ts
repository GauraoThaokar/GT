import { AccountDetails } from "./account-details";
import { Cibil } from "./cibil";
import { CurrentLoanDetails } from "./current-loan-details";
import { CustomerVerification } from "./customer-verification";
import { GuarantorDetail } from "./guarantor-detail";
import { Profession } from "./profession";

export class Customer {
  cId: number;
  cname:String;
  // cibil:Cibil;
   currentloandetails:CurrentLoanDetails;
  // customerverification:CustomerVerification;
  // profession:Profession;
  accountdetails:AccountDetails;
  // guarantorDetail:GuarantorDetail;
  
  
  }


