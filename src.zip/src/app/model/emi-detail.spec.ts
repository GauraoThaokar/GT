import { EmiDetail } from './emi-detail';

describe('EmiDetail', () => {
  it('should create an instance', () => {
    expect(new EmiDetail()).toBeTruthy();
  });
});
