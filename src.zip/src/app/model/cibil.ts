export class Cibil {
    cibilScore:number;
    cibilStatus:String;
    cibilRemark:String;



}
