package com.cjc.main.service;

public interface SerSanctionLetter {

}
