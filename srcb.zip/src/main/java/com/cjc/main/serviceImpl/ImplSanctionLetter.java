package com.cjc.main.serviceImpl;

import org.springframework.stereotype.Service;

import com.cjc.main.service.SerSanctionLetter;

@Service
public class ImplSanctionLetter implements SerSanctionLetter{

}
