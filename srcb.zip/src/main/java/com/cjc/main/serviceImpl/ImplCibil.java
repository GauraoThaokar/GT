package com.cjc.main.serviceImpl;

import org.springframework.stereotype.Service;

import com.cjc.main.service.SerCibil;

@Service
public class ImplCibil implements SerCibil{
	

}
