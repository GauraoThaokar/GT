package com.cjc.main.model;

public class EmiCalculator {
	
	

}
